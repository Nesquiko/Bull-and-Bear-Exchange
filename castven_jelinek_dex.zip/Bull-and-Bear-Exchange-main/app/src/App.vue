<template>
  <Suspense>
    <Exchange />
  </Suspense>
</template>
<script setup lang="ts">
import Exchange from '@/Exchange.vue';
</script>
